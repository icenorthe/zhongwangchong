# PythonAnywhere Setup

This guide deploys the order site to PythonAnywhere with a free fixed URL:

- `https://<your-username>.pythonanywhere.com`

The hosted app only accepts and displays orders.
It does not run the local execution worker on PythonAnywhere.

## 1) Create account

1. Create a free account on PythonAnywhere.
2. Choose a username carefully because the free site URL uses it directly.

## 2) Upload code

Use one of these:

- Upload this project as a zip in the Files tab and unzip it.
- Or push to Git and clone it from a Bash console.

Example target path:

```bash
/home/<your-username>/zhongwang-charge
```

## 3) Create virtualenv and install dependencies

Open a Bash console on PythonAnywhere:

```bash
cd /home/<your-username>/zhongwang-charge
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements_mobile.txt
```

## 4) Create web app

In PythonAnywhere Web tab:

1. Click `Add a new web app`
2. Choose the free domain:
   - `<your-username>.pythonanywhere.com`
3. Choose `Manual configuration`
4. Choose Python `3.12`
5. Switch the web app to `ASGI`

## 5) Point ASGI config to this project

Open the generated ASGI config file from the Web tab and replace its contents with:

```python
import os
import sys

project_home = "/home/<your-username>/zhongwang-charge"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

os.chdir(project_home)

from pythonanywhere_app import app
```

## 6) Set virtualenv and reload

In the Web tab:

1. Set virtualenv path to:
   - `/home/<your-username>/zhongwang-charge/.venv`
2. Click `Reload`

## 7) Verify

Open:

- `https://<your-username>.pythonanywhere.com/`
- `https://<your-username>.pythonanywhere.com/api/health`

Expected health result:

- `worker_enabled` is `false`
- orders can be created and stay in `PENDING`

## 8) Prepare for later local execution

The server already exposes agent APIs for a future local PC agent:

- `POST /api/agent/orders/claim`
- `POST /api/agent/orders/{order_id}/complete`

Recommended environment variables for later:

- `ADMIN_TOKEN`
- `AGENT_TOKEN`
- `WORKER_ENABLED=0`

If you want, the next step can be building a Windows local agent that polls
PythonAnywhere and runs `local_charge_runner.py`.
